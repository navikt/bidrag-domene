#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import no.nav.bidrag.domain.felles.Verdiobjekt
import org.springframework.core.convert.converter.Converter

data class ${NAME}(override val verdi: Boolean) : Verdiobjekt<Boolean>

class ${NAME}ReadingConverter : Converter<Boolean, ${NAME}> {
    override fun convert(source: Boolean) = ${NAME}(source)
}

class ${NAME}WritingConverter : Converter<${NAME}, Boolean> {
    override fun convert(source: ${NAME}) = source.verdi
}

class ${NAME}Converter : AttributeConverter<Boolean, ${NAME}> {
    override fun convertToDatabaseColumn(p0: Boolean?) = p0?.let { ${NAME}(p0) }
    override fun convertToEntityAttribute(p0: ${NAME}?) = p0?.verdi
}
