@file:Suppress("unused")

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import java.sql.Timestamp
import java.time.LocalDateTime
import no.nav.bidrag.domain.felles.Verdiobjekt
import org.springframework.core.convert.converter.Converter

class ${NAME}(override val verdi: LocalDateTime) : Verdiobjekt<LocalDateTime>()

class ${NAME}ReadingConverter : Converter<Timestamp, ${NAME}> {
    override fun convert(source: Timestamp) = ${NAME}(source.toLocalDateTime())
}

class ${NAME}WritingConverter : Converter<${NAME}, Timestamp> {
    override fun convert(source: ${NAME}) = Timestamp.valueOf(source.verdi)
}

class ${NAME}Converter : AttributeConverter<${NAME}, LocalDateTime> {
    override fun convertToEntityAttribute(source: LocalDateTime?) = source?.let { ${NAME}(source) }
    override fun convertToDatabaseColumn(source: ${NAME}?) = source?.verdi
}
